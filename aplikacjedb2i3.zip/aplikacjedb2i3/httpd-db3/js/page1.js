var app = angular.module('app', []);   //definicja nowej aplikacji

app.controller('Page1Ctrl', ['$http',
	function($http) {
		
		console.log("Controller starting");
		
		var self = this;

		self.person = {};		
		
		var refresh = function() {
			$http.get('/db/persons/').then(
				function(response) {
					self.persons = response.data;
				},
				function(errResponse) {
					self.persons = [];
				}
			);
		}
		
		refresh();
		
		self.insert = function() {
			$http.post('/persons/json', self.person).then(
				function(response) {
					refresh();
				},
				function(errResponse) {
					console.log(JSON.stringify(errResponse));
				}
			);
		} 
	}
]);