var fs = require('fs');
var http = require('http');
var path = require('path');
var mime = require('mime');

var debugLog = true; // turning on logging to the console

function serveFile(rep, fileName, errorCode, message) {
	
	if(debugLog) console.log('Serving file ' + fileName + (message ? ' with message \'' + message + '\'': ''));
	
    fs.readFile(fileName, function(err, data) {
		if(err) {
            serveError(rep, 404, 'Document ' + fileName + ' not found');
        } else {
			rep.writeHead(errorCode, message, { 'Content-Type': mime.getType(path.basename(fileName)) });
			if(message) {
				data = data.toString().replace('{errMsg}', rep.statusMessage).replace('{errCode}', rep.statusCode);
			}
			rep.end(data);
        }
      });
}

function serveError(rep, error, message) {
	serveFile(rep, 'html/error.html', error, message);
}

function logIn(req, rep) {
	var item = '';
	req.setEncoding('utf8');
	req.on('data', function(chunk) {
		item += chunk;
	}).on('end', function() {
		var cred = JSON.parse(item);
		console.log('Trying to login: ' + JSON.stringify(cred));
		if(cred.login == 'admin' && cred.password == 'admin1') {
			console.log('Login successful');
			rep.writeHead(200, 'Login successful', { 'Content-Type': 'application/json' });
			rep.end(JSON.stringify({ login: cred.login }));
		} else {
			console.log('Login failed');
			rep.writeHead(401, 'Login failed', { 'Content-Type': 'application/json' });
			rep.end(JSON.stringify( { login: cred.login } ));
		}
	});
}

var listeningPort = 8888;

http.createServer().on('request', function (req, rep) {
	
	if(debugLog) console.log('HTTP request URL: ' + req.url);
	
	switch(req.url) {
		case '/':
			serveFile(rep, 'html/index.html', 200, '');
			break;
		case '/favicon.ico':
			serveFile(rep, 'img/favicon.ico', 200, '');
			break;
		case '/auth':
			if(req.method == 'POST')
				logIn(req, rep);
			else
				serveError(rep, 405, 'Method not allowed');
			break;
		default:
			if(/^\/(html|css|js|fonts|img)\//.test(req.url)) {
				var fileName = path.normalize('./' + req.url)
				serveFile(rep, fileName, 200, '');
			} else {	
				serveError(rep, 403, 'Access denied');
			}
		}
	}
).listen(listeningPort);

console.log('The server is listening on port ' + listeningPort);