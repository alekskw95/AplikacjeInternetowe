var debugLog = false;

var dbName = 'mydb1';

if(debugLog) console.log('Initialization of \'' + dbName + '\'');

var mongojs = require('mongojs');
var db = mongojs(dbName);

var persons = db.collection('persons');

if(debugLog) console.log('Delete collection \'persons\'');
persons.drop();

personsExample = [
	{ firstName: 'Dmitrii', lastName: 'Mitroshenkov' },
	{ firstName: 'Chowdhury', lastName: 'Joy Barua' },
	{ firstName: 'Adrian', lastName: 'Gryza' },
	{ firstName: 'Myroslav', lastName: 'Dmukhivskyi' },
	{ firstName: 'Patryk', lastName: 'Dudka' },
	{ firstName: 'Igor', lastName: 'Gwiazdowski' },
	{ firstName: 'Adrian', lastName: 'Bus' }
];

if(debugLog) console.log('Creating new collection \'persons\'');
for(var i in personsExample) {
	if(debugLog) {
		console.log(JSON.stringify(personsExample[i]));
	}
	persons.insert(personsExample[i]);
}

if(debugLog) console.log('End of initialization');