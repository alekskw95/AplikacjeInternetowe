var dbName = 'mydb1';

var merge = require('merge');
var mongojs = require('mongojs');

var db = mongojs(dbName);

module.exports = {
	
	serve:
	
		function(request, response, collName) {
			select(collName, function(err, nRecords, docs) {
				if(err) sendError(response, err); else sendJson(response, docs, { 'X-Records': nRecords });
			});
		}
}

function sendJson(response, obj, extraHeaders) {
  response.writeHead(200, merge({'Content-Type': 'application/json'}, extraHeaders));
  response.end(JSON.stringify(obj));
}

function sendError(response, obj) {
  response.writeHead(400, {'Content-Type': 'application/json'});
  response.end(JSON.stringify(obj));
}

function select(collName, callback) {
	var collection = db.collection(collName);
	var cursor = collection.find();
	cursor.count(function(err, nRecords) {
		if(err) {
			callback(err, 0, []);
		} else {
			cursor.toArray(function (err, docs) {
				callback(err, nRecords, docs);
			});
		}
	});
}