app.controller('Page2', ['$http',
	function($http) {	
		var self = this;
		console.log('Page 2 controller started');
	}
]);