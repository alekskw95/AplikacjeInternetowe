var debugLog = false;

var dbName = 'mydb1';

if(debugLog) console.log('Initialization of \'' + dbName + '\'');

var mongojs = require('mongojs');
var db = mongojs(dbName);

var persons = db.collection('persons');

if(debugLog) console.log('Delete collection \'persons\'');
persons.drop();

personsExample = [
	{ firstName: 'Dmitrii', lastName: 'Mitroshenkov', email: 'dm@dm.com', password: 'dm' },
	{ firstName: 'Chowdhury', lastName: 'Joy Barua', email: 'jb@jb.com', password: 'jb' },
	{ firstName: 'Adrian', lastName: 'Gryza', email: 'ag@ag.com', password: 'ag' },
	{ firstName: 'Myroslav', lastName: 'Dmukhivskyi', email: 'md@md.com', password: 'md' },
	{ firstName: 'Patryk', lastName: 'Dudka', email: 'pd@pd.com', password: 'pd' },
	{ firstName: 'Igor', lastName: 'Gwiazdowski', email: 'ig@ig.com', password: 'ig' },
	{ firstName: 'Adrian', lastName: 'Bus', email: 'ab@ab.com', password: 'ab' }
];

if(debugLog) console.log('Creating new collection \'persons\'');
for(var i in personsExample) {
	if(debugLog) {
		console.log(JSON.stringify(personsExample[i]));
	}
	persons.insert(personsExample[i]);
}

if(debugLog) console.log('End of initialization');