app.constant('routes', [
			{ route: '/', templateUrl: 'html/home.html', controller: 'Home', controllerAs: 'ctrl' },
			{ route: '/1', templateUrl: 'html/page1.html', controller: 'Page1', controllerAs: 'ctrl', menu: 'Page 1' },
			{ route: '/2', templateUrl: 'html/page2.html', controller: 'Page2', controllerAs: 'ctrl', menu: 'Page 2' },
			{ route: '/3', templateUrl: 'html/page3.html', controller: 'Page3', controllerAs: 'ctrl', menu: 'Page 3' }
]);

app.config(['$routeProvider', 'routes', function($routeProvider, routes) {
	for(var i in routes) {
		$routeProvider.when(routes[i].route, routes[i]);
	}
	$routeProvider.otherwise({ redirectTo: '/' });
}]);

app.controller('Menu', ['$location', 'routes',
	function($location, routes) {
		var self = this;

		self.menu = [];
		
		for(var i in routes) {
			if(routes[i].menu) {
				self.menu.push({ route: routes[i].route, title: routes[i].menu });
			}
		}
		
		self.navClass = function(page) {
			console.log(page + "?" + $location.path());
			return page === $location.path() ? 'active' : '';
		}
	}
]);