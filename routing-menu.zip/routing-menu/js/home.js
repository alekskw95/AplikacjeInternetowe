app.controller('Home', ['$http',
	function($http) {	
		var self = this;
		console.log('Home page controller started');
	}
]);